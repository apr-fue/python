from tkinter import *

master = Tk()
master.geometry("500x500")
master.config(bg = "black")
baseFrame = Frame(master, width = 499, height = 499, bg = "black")
baseFrame.grid(sticky = NSEW)

frame1 = Frame(baseFrame, width = 200, height = 150, bg = "blue")
frame1.grid(row = 1, column = 0)
lbl = Label(baseFrame, bg = "blue", text = "blue" )
lbl.grid(row = 1, column = 0)

frame2 = Frame(baseFrame, width = 200, height = 150, bg = "Red")
frame2.grid(row = 2, column = 0)
lbl = Label(baseFrame, bg = "red", text = "red")
lbl.grid(row = 2, column = 0)

frame3 = Frame(baseFrame, width = 200, height = 150, bg = "green")
frame3.grid(row = 1, column = 1)
lbl = Label(baseFrame, bg = "green", text = "green")
lbl.grid(row = 1, column = 1)

frame4 = Frame(baseFrame, width = 200, height = 150, bg = "Yellow")
frame4.grid(row = 2, column = 1)
lbl = Label(baseFrame, bg = "yellow", text = "yellow")
lbl.grid(row = 2, column = 1)

frame5 = Frame(baseFrame, width = 400, height = 200, bg = "purple")
frame5.grid(row = 0, columnspan = 2)
lbl = Label(baseFrame, bg = "purple", text = "purple")
lbl.grid(row = 0, columnspan = 2)

master.mainloop()