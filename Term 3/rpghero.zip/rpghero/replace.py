def equipBoots(self):
    for i in self.inventory:
        x = type(i)
        if "Gloves" in str(x):
            if len(self.bootseq) < 1:
                print("You have equipped a pair of gloves.")
                print(i)
                self.bootseq.append(i)
                self.inventory.remove(i)
                self.deff += self.bootseq[0].armour
                self.luck += self.bootseq[0].luck
                self.stamina += self.bootseq[0].stamina
                self.iq += self.bootseq[0].iq
                self.agi += self.bootseq[0].agi
            else:
                print("You are wearing a pair of gloves")
                print(self.bootseq[0])
                print("Would you like to replace them with")
                print(i)
                while True:
                    x = input("yes or no")
                    if x == "yes":
                        print("You replaced your gloves")
                        self.deff -= self.bootseq[0].armour
                        self.luck -= self.bootseq[0].luck
                        self.stamina -= self.bootseq[0].stamina
                        self.iq -= self.bootseq[0].iq
                        self.agi -= self.bootseq[0].agi
                        self.bootseq.remove(self.bootseq[0])
                        self.bootseq.append(i)
                        self.inventory.remove(i)
                        self.deff += self.bootseq[0].armour
                        self.luck += self.bootseq[0].luck
                        self.stamina += self.bootseq[0].stamina
                        self.iq += self.bootseq[0].iq
                        self.agi += self.bootseq[0].agi
                        break
                    elif x == "no":
                        self.inventory.remove(i)
                        break