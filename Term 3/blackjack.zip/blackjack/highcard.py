import cards
value = cards.Card.RANKS.index(self.rank)+1

def Hi_Deck()




