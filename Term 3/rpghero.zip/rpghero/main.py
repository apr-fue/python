from Hero import *
def switch(turn):
    if turn == 0:
        turn = 1
        notturn = 0
    else:
        turn = 0
        notturn = 1
    return turn, notturn

players = []

for i in range(2):
    print("creating plarer ",i+1)
    player = Hero()
    player.equipAll()
    players.append(player)
turn = 0
notturn = 1
while players[0].isAlive:
    print()
    print("it's your attack")
    print(players[turn])
    x = players[turn].attack()
    players[notturn].defense(x)
    if players[1].isAlive == False:
        print(players[1].name, "has died")
        xp, item = players[1].die()
        players[0].collectXp(xp)
        players[0].addToInv(item)
        players[0].equipAll()
        print("A new challenger approaches")
        player = Hero()
        player.equipAll()
        players[1] = player


    turn, notturn = switch(turn)
print("you have died")


