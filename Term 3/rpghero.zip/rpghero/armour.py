import random


class Equipment(object):
    RARITY = ["Trash", "Common", "Rare", "Epic", "Legendary"]

    def __init__(self, eqType):
        self.rarityLevel, self.rareMod = self.pickRare()
        self.eqType = eqType

    def pickRare(self):
        x = random.randint(1, 10)
        if x >= 1 and x <= 2:
            return Equipment.RARITY[0], 2
        elif x > 2 and x <= 5:
            return Equipment.RARITY[1], 4
        elif x > 5 and x < 8:
            return Equipment.RARITY[2], 8
        elif x >= 8 and x <= 9:
            return Equipment.RARITY[3], 16
        elif x == 10:
            return Equipment.RARITY[4], 32


class Armour(Equipment):
    ARMOURTYPE = ["Helm", "Chest", "Legs", "Boots", "Gloves"]

    def __init__(self, aType):
        super(Armour, self).__init__("Armour")
        self.armourType = aType
        self.armour = 0
        self.stamina = 0
        self.agi = 0
        self.iq = 0
        self.luck = 0

    def __str__(self):
        return """
        armourType: {}
        Rarity Level: {}
        Armour: {}
        Luck: {}
        Stamina: {}
        Agility: {}
        """.format(self.armourType, self.rarityLevel, self.armour, self.luck, self.stamina, self.iq, self.agi)


class Helm(Armour):
    def __init__(self):
        super(Helm, self).__init__(Armour.ARMOURTYPE[0])
        self.armour = random.randint(5, 10) * self.rareMod
        self.stamina = random.randint(0, 8) + self.rareMod
        self.agi = random.randint(0, 8) + self.rareMod
        self.iq = random.randint(0, 8) + self.rareMod
        self.luck = random.randint(0, 8) + self.rareMod


class Chest(Armour):
    def __init__(self):
        super(Chest, self).__init__(Armour.ARMOURTYPE[1])
        self.armour = random.randint(5, 25) * self.rareMod
        self.stamina = random.randint(0, 25) + self.rareMod
        self.agi = random.randint(0, 25) + self.rareMod
        self.iq = random.randint(0, 25) + self.rareMod
        self.luck = random.randint(0, 25) + self.rareMod


class Legs(Armour):
    def __init__(self):
        super(Legs, self).__init__(Armour.ARMOURTYPE[2])
        self.armour = random.randint(5, 15) * self.rareMod
        self.stamina = random.randint(0, 15) + self.rareMod
        self.agi = random.randint(0, 15) + self.rareMod
        self.iq = random.randint(0, 15) + self.rareMod
        self.luck = random.randint(0, 15) + self.rareMod


class Boots(Armour):
    def __init__(self):
        super(Boots, self).__init__(Armour.ARMOURTYPE[3])
        self.armour = random.randint(5, 10) * self.rareMod
        self.stamina = random.randint(0, 8) + self.rareMod
        self.agi = random.randint(0, 8) + self.rareMod
        self.iq = random.randint(0, 8) + self.rareMod
        self.luck = random.randint(0, 8) + self.rareMod


class Gloves(Armour):
    def __init__(self):
        super(Gloves, self).__init__(Armour.ARMOURTYPE[4])
        self.armour = random.randint(5, 8) * self.rareMod
        self.stamina = random.randint(0, 5) + self.rareMod
        self.agi = random.randint(0, 5) + self.rareMod
        self.iq = random.randint(0, 5) + self.rareMod
        self.luck = random.randint(0, 5) + self.rareMod
