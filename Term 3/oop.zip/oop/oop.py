import datetime
import random
import time
class Person():
   def __init__(self, fname, lname, height, lbs , haircolor, eyecolor):
       self.alive = True
       self.first_name = fname
       self.last_name = lname
       self.gender = ""
       self.race = ""
       self.age = 0
       self.bday = datetime.datetime.now()
       self.height = height
       self.lbs = lbs
       self.hair_color = haircolor
       self.eye_color = eyecolor
       self.delta = datetime.timedelta(seconds=15)
       self.last_bday = self.bday
       self.blood_type = ""
   def intro(self):
       print("Hello my name is", self.first_name,self.last_name)
       print("I was born on ",self.bday)
       print("I am",self.age,"years old")
       print("I have",self.hair_color,"hair and",self.eye_color,"eyes")
       print("I weigh", self.lbs)

   def haveBday(self):
       ctime = datetime.datetime.now()
       nextBDay = self.last_bday+self.delta
       if ctime >= nextBDay:
           self.age+=1
           self.last_bday = ctime
       if self.age>= 100:
           self.die()

   def eat(self):
       foods = ["salad","pizza","ice cream", "apple", "nothing"]
       x = random.choice(foods)
       print("i ate", x)
       if x == foods[0]:
           self.lbs = self.lbs
       elif x == foods[1]:
           self.lbs += 5
       elif x == foods[2]:
           self.lbs  += 12
       elif x == foods[3]:
           self.lbs  += 1
       else:
           self.lbs -= 10
       if self.lbs > 499 or self.lbs < 0:
           self.die()
       if self.lbs > 250:
           x = random.randint(0,10)
           if x == 9:
               self.die()





   def die(self):
       self.alive = False
       print("F")

bob = Person("Bob","Ross",23,12,"brown","blue")
rich_nag = Person("Richard","Nagisa",69,69,"black","black")
chloe = Person("Chloe","Spilker",64,69,"blonde","blue")
ben = Person("Ben","Vielstich",72,69,"brown","blue sometimes green")
joe = Person("Joe", "Mama", 69, 69, "bald", "black")
mlady = Person("Mlady","Fedora", 1, 1, "brown", "brown")



bob.intro()
while bob.alive:
    x = bob.age
    time.sleep(2)
    bob.eat()
    bob.haveBday()
    if bob.age != x:
        bob.intro()
##rich_nag.intro()
##chloe.intro()
##ben.intro()
##joe.intro()
##mlady.intro()
