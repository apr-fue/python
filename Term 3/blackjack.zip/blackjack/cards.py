import random

class Card(object):
    """ A playing card. this class is used to create playing cards that
    have a rank and suit and can be displayed faceup or face down this class has the following methods
    __str__() displays ascii art for the cards
    __init__(rank, suit, face_up) builds the card class
    flip() flips the card"""
    RANKS = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
    SUITS = ["♠","♦","♣","♥"]

    def __init__(self, rank, suit, face_up = True):
        """constructor method requires the rank suit and face up position to be passed im
        card = Card("A", "♣" face_up = True)"""
        self.rank = rank
        self.suit = suit
        self.is_face_up = face_up

    def __str__(self):
        if self.is_face_up:
            rep = str.format("""
            -------------
            | {0:2} |
            | {1} |
            | |
            | |
            | {1} |
            | {0:2}|
            -------------
            """,self.rank, self.suit)
        else:
                rep = """
                -------------
                |\\ |
                | \\ |
                | \\ |
                | \\ |
                | \\ |
                | \\ |
                -------------
                """
                return rep
    def flip(self):
        self.is_face_up = not self.is_face_up

class Hand(object):
    def __init__(self):
        self.cards = []

    def __str__(self):
        if self.cards:
            rep = ""
            for card in self.cards:
                rep += str(card)+ " "
        else:
            rep = "<Empty>"
            return rep

    def add_card(self, card):
        self.cards.append(card)

    def give_card(self,card, other_hand):
        self.cards.remove(card)
        other_hand.add_card(card)
    def clear_hand(self):
        self.cards = []

class Deck(Hand):
    def pop_cards(self):
        for suit in Card.SUITS:
            for rank in Card.RANKS:
            self.add_card(Card(rank,suit))

    def shuffle(self):
        import random
        random.shuffle(self.cards)

    def deal(self, hands, per_hand = 1):
        for rounds in range(per_hand):
            for hand in hands:
                if self.cards:
                    top_card = self.cards[0]
                    self.give_card(top_card, hand)
                else:
                    print("can't continue to deal. Out of cards!")

                        if __name__ == "__main__":
            print("this is a module with classes for playing cards. not designed to run on its own")
            input("\n\nPress the enter key to exit-")
