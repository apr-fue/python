from tkinter import *
root = Tk()
root.geometry("400x500")
root.title("Window exe")

base = Frame(root, height = 500, width = 400)
base.pack(fill = BOTH)

top = Frame(base, height = 100, bg = "purple")
top.pack(fill = X)
lbl = Label(top, text = "label", bg = "purple")
lbl.pack(pady = 44)

mid = Frame(base, height = 200, bg = "brown")
mid.pack(fill = X)

midleft = Frame(mid, height = 198,width = 198, bg = "red")
midleft.pack(side = LEFT, padx = 1, pady= 1, fill = BOTH)
midright = Frame(mid, height = 198,width = 198,  bg = "blue")
midright.pack(side = LEFT, padx = 1, pady= 1, fill = BOTH)

bttntl = Button(midleft, text = "button")
bttntl.pack()
bttntr = Button(midright, text = "button")
bttntr.pack()

bot = Frame(base, height = 200, bg = "grey")
bot.pack(fill = X)

botleft = Frame(bot, height = 198,width = 198, bg = "green")
botleft.pack(side = LEFT, padx = 1, pady= 1, fill = BOTH)
botright = Frame(bot, height = 198,width = 198,  bg = "yellow")
botright.pack(side = LEFT, padx = 1, pady= 1, fill = BOTH)

root.mainloop()