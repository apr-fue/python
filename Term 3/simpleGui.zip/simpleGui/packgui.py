from tkinter import *
root = Tk()

w = Label(root, text = "Red Sun", bg = "red", fg="white")
w.pack()
w = Label(root, text = "Green Grass", bg = "green", fg="black")
w.pack()
w = Label(root, text = "Blue Sky", bg = "blue", fg="white")
w.pack()

#fill
w = Label(root, text = "Red Sun", bg = "red", fg="white")
w.pack(fill = X)
w = Label(root, text = "Green Gress", bg = "green", fg="black")
w.pack(fill = X)
w = Label(root, text = "Blue Sky", bg = "blue", fg="white")
w.pack(fill = X)

#padding
w = Label(root, text = "Red Sun", bg = "red", fg="white")
w.pack(fill = X, padx = 10, pady = 20)
w = Label(root, text = "Green Gress", bg = "green", fg="black")
w.pack(fill = X, padx = 50, pady = 20)
w = Label(root, text = "Blue Sky", bg = "blue", fg="white")
w.pack(fill = X, padx = 10, pady = 10)

w = Label(root, text = "Red Sun", bg = "red", fg="white")
w.pack(fill = X, ipadx = 10, ipady = 20)
w = Label(root, text = "Green Gress", bg = "green", fg="black")
w.pack(fill = X, ipadx = 50, ipady = 20)
w = Label(root, text = "Blue Sky", bg = "blue", fg="white")
w.pack(fill = X, ipadx = 10, ipady = 10)

#side
w = Label(root, text = "Red Sun", bg = "red", fg="white")
w.pack(fill = X, padx = 10, pady = 20, side = LEFT)
w = Label(root, text = "Green Gress", bg = "green", fg="black")
w.pack(fill = X, padx = 50, pady = 20, side = LEFT)
w = Label(root, text = "Blue Sky", bg = "blue", fg="white")
w.pack(fill = X, padx = 10, pady = 10, side = LEFT)


root.mainloop()