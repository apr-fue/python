from tkinter import *

root = Tk()
root.title("Mad Lib")
root.geometry("605x330")

frame = Frame(root)
frame.grid()

lbl = Label(frame, text = "Enter information for a new story")
lbl.grid()

lbl = Label(frame, text = "Person:")
lbl.grid(sticky = W)

text_ent = Entry(frame)
text_ent.grid(row = 1, column = 1)

lbl = Label(frame, text = "Plural Noun:")
lbl.grid(sticky = W)

text_ent = Entry(frame)
text_ent.grid(row = 2, column = 1)

lbl = Label(frame, text = "Verb:")
lbl.grid(sticky = W)

text_ent = Entry(frame)
text_ent.grid(row = 3, column = 1)

lbl = Label(frame, text = "Adjectives:")
lbl.grid(sticky = W)

is_itchy = BooleanVar()
Checkbutton(frame, text = "itchy", variable = is_itchy).grid(row = 4, column = 1, sticky = W)

is_joyous = BooleanVar()
Checkbutton(frame, text = "joyous", variable = is_joyous).grid(row = 4, column = 2, sticky = W)

is_electric = BooleanVar()
Checkbutton(frame, text = "electric", variable = is_electric).grid(row = 4, column = 3, sticky = W)

lbl = Label(frame, text = "Body part:")
lbl.grid(sticky = W)

body_part = StringVar()
body_part.set(None)
body_parts=["bellybutton", "big toe", "medulla oblongata"]
column = 1
for part in body_parts:
    Radiobutton(frame, text = part, variable = body_part, value = part).grid(row = 5, column = column, sticky = W)
    column += 1

def tell_story(person_ent):
    person = person_ent.get()
    story_txt.delete(0.0, END)
    story_txt.insert(0.0, person)

bttn1 = Button(frame, text = "Click for story", command = tell_story)
bttn1.grid(sticky = W)

story_txt = Text(frame, width = 75, height = 10, wrap = WORD, EDIT)
story_txt.grid(row = 7, column = 0, columnspan = 4)



root.mainloop()