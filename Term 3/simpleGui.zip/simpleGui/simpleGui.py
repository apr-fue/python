from tkinter import *

root = Tk()

root.title("Simple GUI")
root.geometry("500x500")

frame = Frame(root, bg = "pink")
frame.grid()


lbl = Label(frame, text = "owo")
lbl.grid()
lbl = Label(frame, text = "uwu")
lbl.grid()
lbl = Label(frame, text = "qwq")
lbl.grid()
lbl = Label(frame, text = "^w^")
lbl.grid()
lbl = Label(frame, text = ":3")
lbl.grid()

photo = PhotoImage(file = r"C:\Users\april.fuentes\Downloads\output-onlinepngtools.png")

text_ent = Entry(frame)
text_ent.grid()

bttn1 = Button(frame,bg = "red2", text = "death :)" , image = photo , compound = LEFT)
bttn1.grid()

bttn2 = Button(frame,bg = "deep pink", text = "rawr XD")
bttn2.grid()

bttn3 = Button(frame,bg = "yellow", text = "you got that yummy yummy yummy")
bttn3.grid()


root.mainloop()
