# import random as r
# class Player(object):
#     def __init__(self, name):
#         self.name = name
#         self.isAlive = True
#         self.health = 100
#
#     def shoot(self,target):
#         miss = r.randint(0,1)
#         if miss == 1:
#             print("miss")
#         else:
#             target.takedmg()
#     def takedmg(self):
#         dmg_zone = r.randint(0,2)
#         if dmg_zone == 0:
#             print("limb shot")
#             self.health -= 10
#         elif dmg_zone == 0:
#             print("body shot")
#             self.health -= 50
#         else:
#             print("head shot")
#             self.health -= 100
#
#         if self.health <= 0:
#             self.die()
#     def die(self):
#         print("You died lol")
#         self.isAlive = False
#
#     def __str__(self):
#         rep = self.name+" has "+str(self.health)+" health left"
#         return rep
#
# class Alien(Player):
#     def __init__(self):
#         super(Alien,self).__init__("Alien")
#     def die(self):
#         print("You fool. You absolute buffoon. You think you can challenge me in my own realm? \n"\
#               "You think you can rebel against my authority? You dare come into my house and upturn \n"\
#               "my dining tables and spill coffee grounds into my Keurig? You thought you were safe \n"\
#               "behind your chainmail armour behind that screen of yours.")
#         self.isAlive = False
#
# def main():
#     us = Player("Richard Nagisa")
#     alien = Alien()
#     while True:
#         us.shoot(alien)
#         if alien.isAlive:
#             alien.shoot(us)
#         else:
#             break
#
# main()