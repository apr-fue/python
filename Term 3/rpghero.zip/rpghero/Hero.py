import random
from armour import *
from weapon import *

class Hero(object):
    RACELIST = ["Human", "Elf", "Goblin", "Weeb"]
    CLASSLIST = ["Warrior", "Mage", "Hunter", "Waifu"]

    def __init__(self):
        self.isAlive = True
        self.level = 1
        self.race = self.pickRace()
        self.playerClass = self.pickClass()
        self.name = input("enter your hero's name")
        self.xp = 0
        self.xplevelup = 90 + (self.level * 10)

        # health setup
        self.healthMod = 100
        self.maxHealth = self.level * self.healthMod
        self.healAct = self.maxHealth

        # mana setup
        self.manaMod = 10
        self.maxMana = self.level * self.manaMod
        self.manaAct = self.maxMana

        # defense & attack setup
        self.deff = 0
        self.atk = 0
        self.luck = 0
        self.stamina = 0
        self.iq = 0
        self.agi = 0
        self.atklist = []
        self.setMods()


        # setup hero's inventory
        self.inventory = []
        self.popInv()
        self.invmax = 10
        self.helmeq = []
        self.chesteq = []
        self.legeq = []
        self.gloveseq = []
        self.bootseq = []
        self.righthandwep = []
        self.lefthandwep = []

    def popInv(self):
        x = random.randint(0,4)
        for i in range(x):
            y = random.randint(0,1)
            if y == 1:
                self.addToInv("Health Potion")
            else:
                self.addToInv("Mana Potion")
        helm = Helm()
        chest = Chest()
        legs = Legs()
        boots = Boots()
        gloves = Gloves()
        x = random.randint(0,4)
        if x == 0:
            weapon = Sword()
        elif x == 1:
            weapon = Longbow()
        elif x == 2:
            weapon = Lightsaber()
        elif x == 3:
            weapon = Dagger()
        else:
            weapon = Staff()
        self.addToInv(helm)
        self.addToInv(chest)
        self.addToInv(legs)
        self.addToInv(boots)
        self.addToInv(gloves)
        self.addToInv(weapon)

    def addToInv(self,item):
        if len(self.inventory) < 10:
            self.inventory.append(item)
        else:
            print("No more room left in inventory")
            return

    def setMods(self):
        if self.playerClass == "Warrior":
            self.atk = ["normal","Sword strike","Stab"]
            self.deff = random.randint(5, 20)
            self.atk = random.randint(5, 15)
            self.luck = random.randint(1, 4)
            self.stamina = random.randint(15, 20)
            self.iq = 1
            self.agi = random.randint(1, 5)
            self.maxMana = 0
        if self.playerClass == "Mage":
            self.atklist = ["normal", "fireball","Power of Will Byers"]
            self.deff = random.randint(5, 10)
            self.atk = random.randint(10, 20)
            self.luck = random.randint(1, 10)
            self.stamina = random.randint(5, 10)
            self.iq = random.randint(5, 20)
            self.agi = random.randint(1, 5)
            self.manaMod = random.randint(15, 20)
        if self.playerClass == "Hunter":
            self.atklist = ["normal", "Trap","Arrow Strike"]
            self.deff = random.randint(5, 15)
            self.atk = random.randint(8, 18)
            self.luck = random.randint(5, 10)
            self.stamina = random.randint(5, 10)
            self.iq = random.randint(5, 12)
            self.agi = random.randint(5, 15)
        if self.playerClass == "Waifu":
            self.atklist = ["normal", ":)", ":("]
            self.deff = random.randint(90, 100)
            self.atk = 100
            self.luck = 100
            self.stamina = 100
            self.iq = 100
            self.agi = 100
        # if self.race == "Elf":
        #     self.stamina -= 2
        #     self.iq += 2
        # if self.race == "Weeb":
        #     self.deff += 10
        #     self.atk += 10
        #     self.luck += 10
        #     self.stamina -= 5
        #     self.iq += 10
        #     self.agi -= 5

    # intro to character
    def __str__(self):
        return """
        Name : {}\t Race: {}\t Class: {}\t Level:{}
        Health: {}\t Mana: {}\t XP: {}
        Attack: {}\t Defense: {}
        Luck: {} \t Stamina: {}
        IQ: {}    \t Agility: {}
        """.format(self.name, self.race, self.playerClass, self.level, self.healAct, self.manaAct, self.xp, self.atk,
                   self.deff, self.luck, self.stamina, self.iq, self.agi)

    def pickRace(self):
        while True:
            try:
                print(Hero.RACELIST)
                x = input("Pick your race.")
                if x in Hero.RACELIST:
                    return x
            except:
                print("Not a valid option")

    def pickClass(self):
        while True:
            try:
                print(Hero.CLASSLIST)
                x = input("Pick your class.")
                if x in Hero.CLASSLIST:
                    return x
            except:
                print("Not a valid option")

    def die(self):
        if self.healAct <= 0:
            self.isAlive = False
            self.unequipAll()
            dropXp = 20 * self.level
            dropitem = random.choice(self.inventory)
            return dropXp, dropitem
        else:
            return "", ""

    def levelUp(self):
        if self.xp >= self.xplevelup:
            # leveling
            print("You have leveled up!")
            print(self)
            remxp = self.xp - self.xplevelup
            self.level += 1
            self.xplevelup = 90 + (self.level * 10)
            self.xp = remxp

            # health
            self.healthMod = self.healthMod + self.level
            self.maxHealth = self.level * self.healthMod
            self.healAct = self.maxHealth

            # mana
            if self.playerClass != "Warrior":
                self.manaMod = self.manaMod + self.level
                self.maxMana = self.level * self.manaMod
                self.manaAct = self.maxMana

            # increasing stats
        self.levelMod()

    def levelMod(self):
        points = random.randint(1, self.level + 1)
        while points > 0:
            print(
                """           Luck: {}
                Stamina: {}
                IQ: {}
                Agility: {}""".format(self.luck, self.stamina, self.iq, self.agi))
            x = input("What stat would you like to increase?")
            y = int(input("you have " + str(points) + " points to spend how many you would like to put in " + x))
            if x == "Stamina":
                self.stamina += y
                points -= y
            if x == "Luck":
                self.luck += y
                points -= y
            if x == "IQ":
                self.iq += y
                points -= y
            if x == "Agility":
                self.agi += y
                points -= y

        else:
            return

    def collectXp(self, xp):
        print("you picked up "+str(xp)+"xp")
        self.xp += xp
        self.levelUp()

    def equipHelm(self):
        for i in self.inventory:
            x = type(i)
            if "Helm" in str(x):
                if len(self.helmeq) < 1:
                    print("You have equipped a helmet.")
                    print(i)
                    self.helmeq.append(i)
                    self.inventory.remove(i)
                    self.deff += self.helmeq[0].armour
                    self.luck += self.helmeq[0].luck
                    self.stamina += self.helmeq[0].stamina
                    self.iq += self.helmeq[0].iq
                    self.agi += self.helmeq[0].agi
                else:
                    print("You are wearing a helmet.")
                    print(self.helmeq[0])
                    print("Would you like to replace them with")
                    print(i)
                    while True:
                        x = input("yes or no")
                        if x == "yes":
                            print("You replaced your helmet")
                            self.deff -= self.helmeq[0].armour
                            self.luck -= self.helmeq[0].luck
                            self.stamina -= self.helmeq[0].stamina
                            self.iq -= self.helmeq[0].iq
                            self.agi -= self.helmeq[0].agi
                            self.helmeq.remove(self.helmeq[0])
                            self.helmeq.append(i)
                            self.inventory.remove(i)
                            self.deff += self.helmeq[0].armour
                            self.luck += self.helmeq[0].luck
                            self.stamina += self.helmeq[0].stamina
                            self.iq += self.helmeq[0].iq
                            self.agi += self.helmeq[0].agi
                            break
                        elif x == "no":
                            self.inventory.remove(i)
                            break

    def equipChest(self):
        for i in self.inventory:
            x = type(i)
            if "Chest" in str(x):
                if len(self.chesteq) < 1:
                    print("You have equipped chestplate.")
                    print(i)
                    self.chesteq.append(i)
                    self.inventory.remove(i)
                    self.deff += self.chesteq[0].armour
                    self.luck += self.chesteq[0].luck
                    self.stamina += self.chesteq[0].stamina
                    self.iq += self.chesteq[0].iq
                    self.agi += self.chesteq[0].agi
                else:
                    print("You are wearing a chestplate.")
                    print(self.chesteq[0])
                    print("Would you like to replace them with")
                    print(i)
                    while True:
                        x = input("yes or no")
                        if x == "yes":
                            print("You replaced your chestplate.")
                            self.deff -= self.chesteq[0].armour
                            self.luck -= self.chesteq[0].luck
                            self.stamina -= self.chesteq[0].stamina
                            self.iq -= self.chesteq[0].iq
                            self.agi -= self.chesteq[0].agi
                            self.chesteq.remove(self.chesteq[0])
                            self.chesteq.append(i)
                            self.inventory.remove(i)
                            self.deff += self.chesteq[0].armour
                            self.luck += self.chesteq[0].luck
                            self.stamina += self.chesteq[0].stamina
                            self.iq += self.chesteq[0].iq
                            self.agi += self.chesteq[0].agi
                            break
                        elif x == "no":
                            self.inventory.remove(i)
                            break

    def equipLegs(self):
        for i in self.inventory:
            x = type(i)
            if "Legs" in str(x):
                if len(self.legeq) < 1:
                    print("You have equipped legs.")
                    print(i)
                    self.legeq.append(i)
                    self.inventory.remove(i)
                    self.deff += self.legeq[0].armour
                    self.luck += self.legeq[0].luck
                    self.stamina += self.legeq[0].stamina
                    self.iq += self.legeq[0].iq
                    self.agi += self.legeq[0].agi
                else:
                    print("You are wearing legs.")
                    print(self.legeq[0])
                    print("Would you like to replace them with")
                    print(i)
                    while True:
                        x = input("yes or no")
                        if x == "yes":
                            print("You replaced your legs")
                            self.deff -= self.legeq[0].armour
                            self.luck -= self.legeq[0].luck
                            self.stamina -= self.legeq[0].stamina
                            self.iq -= self.legeq[0].iq
                            self.agi -= self.legeq[0].agi
                            self.legeq.remove(self.legeq[0])
                            self.legeq.append(i)
                            self.inventory.remove(i)
                            self.deff += self.legeq[0].armour
                            self.luck += self.legeq[0].luck
                            self.stamina += self.legeq[0].stamina
                            self.iq += self.legeq[0].iq
                            self.agi += self.legeq[0].agi
                            break
                        elif x == "no":
                            self.inventory.remove(i)
                            break

    def equipBoots(self):
        for i in self.inventory:
            x = type(i)
            if "Boots" in str(x):
                if len(self.bootseq) < 1:
                    print("You have equipped a pair of boots.")
                    print(i)
                    self.bootseq.append(i)
                    self.inventory.remove(i)
                    self.deff += self.bootseq[0].armour
                    self.luck += self.bootseq[0].luck
                    self.stamina += self.bootseq[0].stamina
                    self.iq += self.bootseq[0].iq
                    self.agi += self.bootseq[0].agi
                else:
                    print("You are wearing a pair of boots")
                    print(self.bootseq[0])
                    print("Would you like to replace them with")
                    print(i)
                    while True:
                        x = input("yes or no")
                        if x == "yes":
                            print("You replaced your boots")
                            self.deff -= self.bootseq[0].armour
                            self.luck -= self.bootseq[0].luck
                            self.stamina -= self.bootseq[0].stamina
                            self.iq -= self.bootseq[0].iq
                            self.agi -= self.bootseq[0].agi
                            self.bootseq.remove(self.bootseq[0])
                            self.bootseq.append(i)
                            self.inventory.remove(i)
                            self.deff += self.bootseq[0].armour
                            self.luck += self.bootseq[0].luck
                            self.stamina += self.bootseq[0].stamina
                            self.iq += self.bootseq[0].iq
                            self.agi += self.bootseq[0].agi
                            break
                        elif x == "no":
                            self.inventory.remove(i)
                            break

    def equipGloves(self):
        for i in self.inventory:
            x = type(i)
            if "Gloves" in str(x):
                if len(self.gloveseq) < 1:
                    print("You have equipped a pair of gloves.")
                    print(i)
                    self.gloveseq.append(i)
                    self.inventory.remove(i)
                    self.deff += self.gloveseq[0].armour
                    self.luck += self.gloveseq[0].luck
                    self.stamina += self.gloveseq[0].stamina
                    self.iq += self.gloveseq[0].iq
                    self.agi += self.gloveseq[0].agi
                else:
                    print("You are wearing a pair of gloves")
                    print(self.gloveseq[0])
                    print("Would you like to replace them with")
                    print(i)
                    while True:
                        x = input("yes or no")
                        if x == "yes":
                            print("You replaced your gloves")
                            self.deff -= self.gloveseq[0].armour
                            self.luck -= self.gloveseq[0].luck
                            self.stamina -= self.gloveseq[0].stamina
                            self.iq -= self.gloveseq[0].iq
                            self.agi -= self.gloveseq[0].agi
                            self.gloveseq.remove(self.gloveseq[0])
                            self.gloveseq.append(i)
                            self.inventory.remove(i)
                            self.deff += self.gloveseq[0].armour
                            self.luck += self.gloveseq[0].luck
                            self.stamina += self.gloveseq[0].stamina
                            self.iq += self.gloveseq[0].iq
                            self.agi += self.gloveseq[0].agi
                            break
                        elif x == "no":
                            self.inventory.remove(i)
                            break

    def equipAll(self):
        self.equipHelm()
        self.equipChest()
        self.equipLegs()
        self.equipBoots()
        self.equipGloves()
        self.equipWeapon()

    def unequipAll(self):
        try:
            self.addToInv(self.helmeq.pop(0))
            self.addToInv(self.chesteq.pop(0))
            self.addToInv(self.legeq.pop(0))
            self.addToInv(self.bootseq.pop(0))
            self.addToInv(self.gloveseq.pop(0))
            self.addToInv(self.righthandweq.pop(0))
            self.addToInv(self.lefthandwep.pop(0))
        except:
            pass



    def equipWeapon(self):
        for i in self.inventory:
            try:
                if i.eqType == "Weapon":
                    while True:
                        x = input("Would you like to equip the weapon in your right or left hand?")
                        if x == "right":
                            if len(self.righthandwep) < 1:
                                print("You have equipped a weapon in that hand.")
                                print(i)
                                self.righthandwep.append(i)
                                self.inventory.remove(i)
                                self.atk += self.righthandwep[0].damage
                                self.luck += self.righthandwep[0].luck
                                self.stamina += self.righthandwep[0].stamina
                                self.iq += self.righthandwep[0].iq
                                self.agi += self.righthandwep[0].agi
                                break
                            else:
                                print("You already have a weapon in that hand.")
                                print(self.righthandwep[0])
                                print("Would you like to replace it with")
                                print(i)
                                while True:
                                    x = input("yes or no")
                                    if x == "yes":
                                        print("You have replaced your right hand weapon.")
                                        self.atk -= self.righthandwep[0].damage
                                        self.luck -= self.righthandwep[0].luck
                                        self.stamina -= self.righthandwep[0].stamina
                                        self.iq -= self.righthandwep[0].iq
                                        self.agi -= self.righthandwep[0].agi
                                        self.righthandwep.remove(self.righthandwep[0])
                                        self.righthandwep.append(i)
                                        self.inventory.remove(i)
                                        self.atk += self.righthandwep[0].attack
                                        self.luck += self.righthandwep[0].luck
                                        self.stamina += self.righthandwep[0].stamina
                                        self.iq += self.righthandwep[0].iq
                                        self.agi += self.righthandwep[0].agi
                                        break
                                    elif x == "no":
                                        self.inventory.remove(i)
                                        break
                                    break

                        else:
                            if len(self.lefthandwep) < 1:
                                print("You have equipped a weapon in that hand.")
                                print(i)
                                self.lefthandwep.append(i)
                                self.inventory.remove(i)
                                self.atk += self.lefthandwep[0].damage
                                self.luck += self.lefthandwep[0].luck
                                self.stamina += self.lefthandwep[0].stamina
                                self.iq += self.lefthandwep[0].iq
                                self.agi += self.lefthandwep[0].agi
                                break
                            else:
                                print("You already have a weapon in that hand.")
                                print(self.lefthandwep[0])
                                print("Would you like to replace it with")
                                print(i)
                                while True:
                                    x = input("yes or no")
                                    if x == "yes":
                                        print("You have replaced your left hand weapon.")
                                        self.atk -= self.lefthandwep[0].attack
                                        self.luck -= self.lefthandwep[0].luck
                                        self.stamina -= self.lefthandwep[0].stamina
                                        self.iq -= self.lefthandwep[0].iq
                                        self.agi -= self.lefthandwep[0].agi
                                        self.lefthandwep.remove(self.lefthandwep[0])
                                        self.lefthandwep.append(i)
                                        self.inventory.remove(i)
                                        self.atk += self.lefthandwep[0].damage
                                        self.luck += self.lefthandwep[0].luck
                                        self.stamina += self.lefthandwep[0].stamina
                                        self.iq += self.lefthandwep[0].iq
                                        self.agi += self.lefthandwep[0].agi
                                        break
                                    elif x == "no":
                                        self.inventory.remove(i)
                                        break
                                    break


            except:
                pass

    def hpPotion(self):
        for i in self.inventory:
            if i == "Health Potion":
                self.healthAct = self.maxHealth
                self.inventory.remove(i)
                return

    def manaPotion(self):
        for i in self.inventory:
            if i == "Mana Potion":
                self.manaAct = self.maxMana
                self.inventory.remove(i)
                return

    def attack(self):
        roll = random.randint(0,10)
        if roll == 1:
            print("miss :(")
            return 0
        roll = random.randint(1,12)
        for i in range(len(self.atklist)):
            print(i + 1, self.atklist[i])
        if self.playerClass == "Warrior":
            while True:
                x = input("What attack would you like to use? 1 2 or 3 or 4 to use a health potion ")
                if x =="1":
                        attk = ((self.atk + self.stamina)*roll)*.1
                        break
                elif x == "2" and self.stamina > 10:
                        attk = ((self.atk + self.stamina) * roll * 2) * .1
                        break
                elif x == "3" and self.stamina >20:
                        attk = ((self.atk + self.stamina) * roll * 2) * .1
                        break
                elif x == "4":
                    self.hpPotion()
                    attk = 0
                    break
                else:
                    print("Not an option")

        elif self.playerClass == "Mage":
            while True:
                x = input("What attack would you like to use? 1 2 or 3 or 4 to use a health potion or 5 to use a mana potion")
                if x == "1" and self.manaAct >1:
                    attk = ((self.atk + self.iq) * roll) * .1
                    self.manaAct -=1
                    break
                elif x == "2" and self.manaAct > 3:
                    attk = ((self.atk + self.iq) * roll * 2) * .1
                    self.manaAct -=2
                    break
                elif x == "3" and self.manaAct > 5:
                    attk = ((self.atk + self.iq) * roll * 2) * .1
                    self.manaAct -=6
                    break
                elif x == "4":
                    self.hpPotion()
                    atkk = 0
                    break
                elif x == "5":
                    self.manaPotion()
                    attk = 0
                    break
                else:
                    print("Not an option")

        elif self.playerClass == "Hunter":
            while True:
                x = input("What attack would you like to use? 1 2 or 3 or 4 to use a health potion or 5 to use a mana potion")
                if x == "1" and self.agi >1:
                    attk = ((self.atk + self.agi) * roll) * .1
                    self.manaAct -= 1
                    break
                elif x == "2" and self.agi > 3:
                    attk = ((self.atk + self.agi) * roll * 2) * .1
                    self.manaAct -= 2
                    break
                elif x == "3" and self.agi > 5:
                    attk = ((self.atk + self.agi) * roll * 2) * .1
                    self.manaAct -= 6
                    break
                elif x == "4":
                    self.hpPotion()
                    atkk = 0
                    break
                elif x == "5":
                    self.manaPotion()
                    attk = 0
                    break
                else:
                    print("Not an option")

        elif self.playerClass == "Waifu":
            while True:
                x = input("What attack would you like to use? 1 2 or 3 or 4 to use a health potion or 5 to use a mana potion")
                if x == "1":
                    attk = ((self.atk + self.luck) * roll) * .1
                    self.manaAct -= 1
                    break
                elif x == "2" and self.luck > 10:
                    attk =((self.atk + self.luck) * roll * 2) * .1
                    self.manaAct -= 2
                    break
                elif x == "3" and self.luck > 20:
                    attk = ((self.atk + self.luck) * roll * 2) * .1
                    self.manaAct -= 6
                    break
                elif x == "4":
                    self.hpPotion()
                    atkk = 0
                    break
                elif x == "5":
                    self.manaPotion()
                    attk = 0
                    break
                else:
                    print("Not an option")
        print(self.name,"did",attk,"damage")
        return attk


    def defense(self, damage):
        dmg = damage
        roll = random.randint(1,10)
        if roll == 7:
            print("blocked lol")
            dmg = 0
        roll = random.randint(1,6)
        if self.playerClass == "Warrior":
            block = ((self.deff + self.stamina) * roll) * .1
        elif self.playerClass == "Hunter":
            block = ((self.deff + self.agi) * roll) * .1
        elif self.playerClass == "Mage":
            block = ((self.deff + self.iq) * roll) * .1
        else:
            block = ((self.deff + self.luck) * roll) * .1
        print(self.name, "blocked", block, "damage")
        dmgdealt = dmg - block
        if dmgdealt >= 0:
            self.healAct = self.healAct - dmgdealt
        if self.healAct <= 0:
            self.isAlive = False















