from armour import *

class Weapon(Equipment):
    WEAPONTYPE = ["Sword", "Longbow", "Lightsaber", "Dagger", "Staff"]

    def __init__(self, aType):
        super(Weapon, self).__init__("Weapon")
        self.aType = aType
        self.strength = 0
        self.stamina = 0
        self.agi = 0
        self.iq = 0
        self.luck = 0
        self.atk = 0
        self.damage = 0

    def __str__(self):
        return """
        armorType: {}
        Rarity Level: {}
        Armor: {}
        Luck: {}
        Stamina: {}
        IQ: {}
        Agility: {}
        """.format(self.aType, self.rarityLevel, self.strength, self.luck, self.stamina, self.iq, self.agi)
class Sword(Weapon):
    #Creating each weapon
    def __init__(self):
        super(Sword, self).__init__(Weapon.WEAPONTYPE[0])
        self.strength = random.randint(5, 10) * self.rareMod
        self.stamina = random.randint(0, 8) + self.rareMod
        self.agi = random.randint(0, 8) + self.rareMod
        self.iq = random.randint(0, 8) + self.rareMod
        self.luck = random.randint(0, 8) + self.rareMod
        self.atk = random.randint(5,10) + self.rareMod
        self.damage = random.randint(5,10) + self.rareMod

class Longbow(Weapon):
    def __init__(self):
        super(Longbow, self).__init__(Weapon.WEAPONTYPE[1])
        self.strength = random.randint(5, 10) * self.rareMod
        self.stamina = random.randint(0, 8) + self.rareMod
        self.agi = random.randint(0, 5) + self.rareMod
        self.iq = random.randint(0, 8) + self.rareMod
        self.luck = random.randint(10, 15) + self.rareMod
        self.atk = random.randint(5, 10) + self.rareMod
        self.damage = random.randint(5, 10) + self.rareMod

class Lightsaber(Weapon):
    def __init__(self):
        super(Lightsaber, self).__init__(Weapon.WEAPONTYPE[2])
        self.strength = random.randint(20, 50) * self.rareMod
        self.stamina = random.randint(10, 20) + self.rareMod
        self.agi = random.randint(10, 15) + self.rareMod
        self.iq = random.randint(10, 15) + self.rareMod
        self.luck = random.randint(0, 8) + self.rareMod
        self.atk = random.randint(50, 100) + self.rareMod
        self.damage = random.randint(50, 100) + self.rareMod

class Dagger(Weapon):
    def __init__(self):
        super(Dagger, self).__init__(Weapon.WEAPONTYPE[3])
        self.strength = random.randint(2, 5) * self.rareMod
        self.stamina = random.randint(10, 15) + self.rareMod
        self.agi = random.randint(20, 30) + self.rareMod
        self.iq = random.randint(0, 8) + self.rareMod
        self.luck = random.randint(0, 8) + self.rareMod
        self.atk = random.randint(2, 5) + self.rareMod
        self.damage = random.randint(2, 5) + self.rareMod

class Staff(Weapon):
    def __init__(self):
        super(Staff, self).__init__(Weapon.WEAPONTYPE[4])
        self.strength = random.randint(5, 10) * self.rareMod
        self.stamina = random.randint(0, 10) + self.rareMod
        self.agi = random.randint(15, 20) + self.rareMod
        self.iq = random.randint(0, 8) + self.rareMod
        self.luck = random.randint(0, 8) + self.rareMod
        self.atk = random.randint(5, 10) + self.rareMod
        self.damage = random.randint(5, 10) + self.rareMod
